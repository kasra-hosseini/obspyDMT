ObsPyDMT
========

Copyright
---------
GNU Lesser General Public License, Version 3 (LGPLv3)

Copyright (c) 2012-2013 by:
    * Kasra Hosseini

Overview
--------
ObsPyDMT (ObsPy Data Management Tool) is a command line tool for retrieving, 
processing and management of massive seismic data in a fully automatic way 
which could be run in serial or in parallel. 
Moreover, complementary processing and managing tools have been designed 
and introduced in addition to the ObsPyDMT options. 
Because of the modular nature, different functionalities could be added easily 
and/or each scripts can be used as a module for other programs.
